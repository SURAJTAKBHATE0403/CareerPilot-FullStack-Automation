package com.suraj.careerpilot.careerpilot_api.controllers;

import com.suraj.careerpilot.careerpilot_api.models.JobApplication;
import com.suraj.careerpilot.careerpilot_api.services.JobApplicationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/jobs")
@CrossOrigin(origins = "http://localhost:4200") // Crucial: Allows your future Angular frontend to call these APIs without CORS errors
public class JobApplicationController {

    @Autowired
    private JobApplicationService jobApplicationService;

    // 1. GET /api/jobs -> Used by Angular Dashboard to show all jobs
    @GetMapping
    public ResponseEntity<List<JobApplication>> getAllJobs() {
        List<JobApplication> jobs = jobApplicationService.getAllApplications();
        return new ResponseEntity<>(jobs, HttpStatus.OK); // Returns 200 OK
    }

    // 2. POST /api/jobs/log -> Used by Python bot to send new scraped jobs
    @PostMapping("/log")
    public ResponseEntity<?> logNewJob(@RequestBody JobApplication application) {
        try {
            JobApplication savedJob = jobApplicationService.logApplication(application);
            return new ResponseEntity<>(savedJob, HttpStatus.CREATED); // Returns 201 Created
        } catch (IllegalArgumentException e) {
            // If the bot tries to send a duplicate job, we catch the error from the Service layer and return a 400 Bad Request
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 3. PATCH /api/jobs/{id}/status -> Used by Python bot to update the status (e.g., PENDING to APPLIED)
    @PatchMapping("/{id}/status")
    public ResponseEntity<?> updateJobStatus(
            @PathVariable Long id,
            @RequestParam String status,
            @RequestParam(required = false) String notes) {
        try {
            JobApplication updatedJob = jobApplicationService.updateStatus(id, status, notes);
            return new ResponseEntity<>(updatedJob, HttpStatus.OK);
        } catch (RuntimeException e) {
            // If the ID isn't found in the database, return a 404 Not Found
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }
}