package com.suraj.careerpilot.careerpilot_api.repositories;

import com.suraj.careerpilot.careerpilot_api.models.JobApplication;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface JobApplicationRepository extends JpaRepository<JobApplication, Long> {
    
    // Spring Data JPA automatically generates the SQL for these custom methods based on their names!
    
    // Useful for your Angular dashboard to filter jobs by their status
    List<JobApplication> findByStatus(String status);
    
    // Crucial for your Python bot to check if it has already applied for a specific role at a specific company
    boolean existsByCompanyNameAndJobRole(String companyName, String jobRole);
}