package com.suraj.careerpilot.careerpilot_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CareerpilotApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CareerpilotApiApplication.class, args);
	}

}
