package com.suraj.careerpilot.careerpilot_api.controllers;

import com.suraj.careerpilot.careerpilot_api.models.User;
import com.suraj.careerpilot.careerpilot_api.repositories.UserRepository;
import com.suraj.careerpilot.careerpilot_api.utils.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:4200")
public class AuthController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtil jwtUtil;

    // --- Inner Class for Request Data ---
    public static class AuthRequest {
        public String email;
        public String password;
    }

    // 1. REGISTER API (Run this once to create your admin account)
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody AuthRequest request) {
        if (userRepository.findByEmail(request.email).isPresent()) {
            return ResponseEntity.badRequest().body("Error: Email is already registered.");
        }

        User user = new User();
        user.setEmail(request.email);
        // We NEVER save plain text passwords in the database!
        user.setPassword(passwordEncoder.encode(request.password)); 
        
        userRepository.save(user);
        return ResponseEntity.ok("User registered successfully!");
    }

    // 2. LOGIN API (Returns the JWT Token)
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody AuthRequest request) {
        try {
            // This checks if the raw password matches the hashed password in the DB
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(request.email, request.password)
            );

            // If successful, generate the JWT token
            final UserDetails userDetails = userDetailsService.loadUserByUsername(request.email);
            final String jwtToken = jwtUtil.generateToken(userDetails);

            // Return the token as JSON
            Map<String, String> response = new HashMap<>();
            response.put("token", jwtToken);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Error: Invalid email or password");
        }
    }
}