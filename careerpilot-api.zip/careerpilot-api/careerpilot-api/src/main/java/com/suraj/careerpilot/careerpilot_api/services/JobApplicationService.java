package com.suraj.careerpilot.careerpilot_api.services;

import com.suraj.careerpilot.careerpilot_api.models.JobApplication;
import com.suraj.careerpilot.careerpilot_api.repositories.JobApplicationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class JobApplicationService {

    @Autowired
    private JobApplicationRepository repository;

    public List<JobApplication> getAllApplications() {
        return repository.findAll();
    }

    public JobApplication logApplication(JobApplication application) {
        boolean alreadyExists = repository.existsByCompanyNameAndJobRole(
                application.getCompanyName(), 
                application.getJobRole()
        );
        
        if (alreadyExists) {
            throw new IllegalArgumentException("A record for this role at this company already exists.");
        }
        
        if ("APPLIED".equalsIgnoreCase(application.getStatus())) {
            application.setAppliedAt(LocalDateTime.now());
        }
        
        return repository.save(application);
    }

    public JobApplication updateStatus(Long id, String newStatus, String notes) {
        Optional<JobApplication> optionalJob = repository.findById(id);
        
        if (optionalJob.isPresent()) {
            JobApplication job = optionalJob.get();
            job.setStatus(newStatus);
            
            if (notes != null && !notes.isEmpty()) {
                job.setNotes(notes);
            }
            
            if ("APPLIED".equalsIgnoreCase(newStatus)) {
                job.setAppliedAt(LocalDateTime.now());
            }
            
            return repository.save(job);
        } else {
            throw new RuntimeException("Job Application not found with ID: " + id);
        }
    }
}