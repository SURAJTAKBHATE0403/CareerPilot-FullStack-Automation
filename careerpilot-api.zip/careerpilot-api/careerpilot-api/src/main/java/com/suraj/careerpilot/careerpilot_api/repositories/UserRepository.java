package com.suraj.careerpilot.careerpilot_api.repositories;

import com.suraj.careerpilot.careerpilot_api.models.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
}