import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth-guard'; 

import { DashboardComponent } from './features/dashboard/pages/dashboard/dashboard'; 
import { LoginComponent } from './features/auth/pages/login/login'; 
// 1. Add this import! (Adjust the path if your file is named slightly differently)
import { ApplicationBoardComponent } from './features/applications/pages/application-board/application-board';

export const routes: Routes = [
  { 
    path: 'login', 
    component: LoginComponent 
  },
  { 
    path: 'dashboard', 
    component: DashboardComponent, 
    canActivate: [authGuard] 
  },
  // 2. ADD THIS NEW BLOCK:
  { 
    path: 'kanban', 
    component: ApplicationBoardComponent, 
    canActivate: [authGuard] // Keep it secure!
  },
  { 
    path: '', 
    redirectTo: '/login', 
    pathMatch: 'full' 
  }
];