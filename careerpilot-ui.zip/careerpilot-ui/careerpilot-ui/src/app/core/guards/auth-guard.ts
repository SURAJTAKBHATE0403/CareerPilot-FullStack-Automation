import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

export const authGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);
  
  // Check if a VIP pass (JWT token) exists in local storage
  const token = localStorage.getItem('token');

  if (token) {
    return true; // Access Granted!
  } else {
    // Access Denied! Send them back to the login screen
    router.navigate(['/login']);
    return false; 
  }
};