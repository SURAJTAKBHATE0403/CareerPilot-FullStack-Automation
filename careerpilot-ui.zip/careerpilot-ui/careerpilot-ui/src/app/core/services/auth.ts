import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private http = inject(HttpClient);
  private router = inject(Router);
  
  // Matches your Spring Boot AuthController
  private readonly BASE_URL = 'http://localhost:8080/api/auth';

  login(email: string, password: string) {
    return this.http.post<{token: string}>(`${this.BASE_URL}/login`, { email, password }).pipe(
      tap(response => {
        // MATCHED: Now saved simply as 'token'
        localStorage.setItem('token', response.token); 
      })
    );
  }

  getToken(): string | null {
    // MATCHED: Now looking for 'token'
    return localStorage.getItem('token');
  }

  isLoggedIn(): boolean {
    return !!this.getToken();
  }

  logout() {
    // MATCHED: Now removes 'token'
    localStorage.removeItem('token');
    this.router.navigate(['/login']);
  }
}