import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Job } from '../../shared/models/job';

@Injectable({ providedIn: 'root' })
export class ApiService {
  private http = inject(HttpClient);
  private baseUrl = 'http://localhost:8080/api/jobs';

  getAllJobs(): Observable<Job[]> {
    return this.http.get<Job[]>(this.baseUrl);
  }

  updateJobStatus(id: number, status: string): Observable<any> {
    // Matches your Spring Boot @PatchMapping("/{id}/status")
    return this.http.patch(`${this.baseUrl}/${id}/status?status=${status}`, {});
  }
}