import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private http = inject(HttpClient);
  private router = inject(Router);
  
  // Matches your Spring Boot AuthController
  private readonly BASE_URL = 'http://localhost:8080/api/auth';

  login(email: string, password: string) {
    return this.http.post<{token: string}>(`${this.BASE_URL}/login`, { email, password }).pipe(
      tap(response => {
        // Save the VIP pass to the browser!
        localStorage.setItem('jwt_token', response.token);
      })
    );
  }

  getToken(): string | null {
    return localStorage.getItem('jwt_token');
  }

  isLoggedIn(): boolean {
    return !!this.getToken();
  }

  logout() {
    localStorage.removeItem('jwt_token');
    this.router.navigate(['/login']);
  }
}