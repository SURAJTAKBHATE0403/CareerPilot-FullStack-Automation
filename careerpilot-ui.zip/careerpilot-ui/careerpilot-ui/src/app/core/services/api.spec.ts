import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
// 1. Change 'Api' to 'ApiService' here
import { ApiService } from './api'; 

describe('ApiService', () => {
  let service: ApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      // 2. Change 'Api' to 'ApiService' here
      providers: [ApiService] 
    });
    // 3. And here
    service = TestBed.inject(ApiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});