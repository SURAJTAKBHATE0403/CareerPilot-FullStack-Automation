import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../../../core/services/api'; 
import { Job } from '../../../../shared/models/job';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule], 
  templateUrl: './dashboard.html'
})
export class DashboardComponent implements OnInit, OnDestroy {
  private apiService = inject(ApiService);
  private refreshTimer: any; // NEW: Variable to hold our timer

  jobs: Job[] = [];
  recentJobs: Job[] = [];
  
  totalJobs = 0;
  appliedJobs = 0;
  skippedJobs = 0;
  pendingJobs = 0;
  successRate = 0;

  ngOnInit(): void {
    this.fetchDashboardData();
    
    // NEW: Automatically fetch new data every 10 seconds (10000 milliseconds)
    this.refreshTimer = setInterval(() => {
      this.fetchDashboardData();
    }, 10000);
  }

  // NEW: Clean up the timer when you navigate away from the dashboard
  ngOnDestroy(): void {
    if (this.refreshTimer) {
      clearInterval(this.refreshTimer);
    }
  }

  fetchDashboardData(): void {
    this.apiService.getAllJobs().subscribe({
      next: (data) => {
        this.jobs = data;
        this.calculateStats();
        this.recentJobs = [...this.jobs].reverse().slice(0, 5);
      },
      error: (err) => console.error('Error fetching jobs:', err)
    });
  }

  calculateStats(): void {
    this.totalJobs = this.jobs.length;
    this.appliedJobs = this.jobs.filter(j => j.status === 'APPLIED').length;
    this.skippedJobs = this.jobs.filter(j => j.status === 'SKIPPED').length;
    this.pendingJobs = this.jobs.filter(j => j.status === 'PENDING').length;

    const actionableJobs = this.appliedJobs + this.skippedJobs;
    if (actionableJobs > 0) {
      this.successRate = Math.round((this.appliedJobs / actionableJobs) * 100);
    }
  }
}