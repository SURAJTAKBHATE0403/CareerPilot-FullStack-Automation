// 1. Add OnInit to your imports from '@angular/core'
import { Component, inject, OnInit } from '@angular/core'; 
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms'; 
import { Router } from '@angular/router';
import { AuthService } from '../../../../core/services/auth';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.html'
})
export class LoginComponent implements OnInit { // 2. Add 'implements OnInit'
  email = '';
  password = '';
  errorMessage = '';
  isLoading = false;

  private authService = inject(AuthService);
  private router = inject(Router);

  // 3. Add this block: It runs the exact moment the login page tries to load
  ngOnInit() {
    // If they already have a token, instantly push them to the dashboard
    if (this.authService.isLoggedIn()) {
      this.router.navigate(['/dashboard']);
    }
  }

  onSubmit() {
    this.isLoading = true;
    this.errorMessage = '';
    
    this.authService.login(this.email, this.password).subscribe({
      next: () => {
        this.router.navigate(['/dashboard']).then(() => window.location.reload());
      },
      error: (err: any) => { 
        this.errorMessage = 'Invalid email or password. Are you registered?';
        this.isLoading = false;
      }
    });
  }
}