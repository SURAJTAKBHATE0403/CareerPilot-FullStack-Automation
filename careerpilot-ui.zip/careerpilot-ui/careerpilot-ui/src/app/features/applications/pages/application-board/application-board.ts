/* This TypeScript code snippet is defining an Angular service called `JobService` that interacts with
an API to manage job-related data. Here's a breakdown of what the code is doing: */
import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CdkDragDrop, moveItemInArray, transferArrayItem, DragDropModule } from '@angular/cdk/drag-drop';
import { ApiService } from '../../../../core/services/api';
import { Job } from '../../../../shared/models/job';

@Component({
  selector: 'app-application-board',
  standalone: true,
  imports: [CommonModule, DragDropModule],
  templateUrl: './application-board.html',
  styleUrl: './application-board.css'
})
export class ApplicationBoardComponent implements OnInit, OnDestroy {
  private apiService = inject(ApiService);
  private refreshTimer: any;

  applied: Job[] = [];
  interview: Job[] = [];
  offer: Job[] = [];
  rejected: Job[] = [];

  // MODAL STATE
  selectedJob: Job | null = null;
  isModalOpen = false;

  ngOnInit(): void {
    this.loadBoardData();
    
    // Refresh the board every 10 seconds
    this.refreshTimer = setInterval(() => {
      this.loadBoardData();
    }, 10000);
  }

  ngOnDestroy(): void {
    if (this.refreshTimer) {
      clearInterval(this.refreshTimer);
    }
  }

  loadBoardData(): void {
    this.apiService.getAllJobs().subscribe({
      next: (jobs) => {
        this.applied = jobs.filter(j => 
          j.status?.toUpperCase() === 'APPLIED' || j.status?.toUpperCase() === 'PENDING'
        );
        this.interview = jobs.filter(j => j.status?.toUpperCase() === 'INTERVIEW');
        this.offer = jobs.filter(j => j.status?.toUpperCase() === 'OFFER');
        this.rejected = jobs.filter(j => 
          j.status?.toUpperCase() === 'REJECTED' || j.status?.toUpperCase() === 'SKIPPED'
        );
      },
      error: (err) => console.error('❌ Error fetching jobs:', err)
    });
  }

  // MODAL METHODS
  openJobDetails(job: Job) {
    this.selectedJob = job;
    this.isModalOpen = true;
  }

  closeModal() {
    this.isModalOpen = false;
    this.selectedJob = null;
  }

  drop(event: CdkDragDrop<Job[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(
        event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex,
      );
      
      const movedJob = event.container.data[event.currentIndex];
      const newStatus = event.container.id.toUpperCase(); 
      
      if (movedJob.id) {
        this.apiService.updateJobStatus(movedJob.id, newStatus).subscribe({
          next: () => console.log('✅ Database updated successfully!'),
          error: (err) => console.error('❌ Failed to update database:', err)
        });
      }
    }
  }
}