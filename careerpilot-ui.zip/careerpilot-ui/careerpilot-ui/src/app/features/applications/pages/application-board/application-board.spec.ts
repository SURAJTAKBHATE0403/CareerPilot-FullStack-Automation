import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplicationBoardComponent } from './application-board'; // Updated here

describe('ApplicationBoardComponent', () => { // Updated here
  let component: ApplicationBoardComponent; // Updated here
  let fixture: ComponentFixture<ApplicationBoardComponent>; // Updated here

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ApplicationBoardComponent] // Updated here
    })
    .compileComponents();

    fixture = TestBed.createComponent(ApplicationBoardComponent); // Updated here
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});