import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { SidebarComponent } from './shared/components/sidebar/sidebar'; // Adjust this name if your class is named differently!

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, SidebarComponent], 
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class AppComponent {
  
  // A simple check to see if the user has a token
  isLoggedIn(): boolean {
    // Returns true if token exists, false if it doesn't
    return !!localStorage.getItem('token');
  }
}