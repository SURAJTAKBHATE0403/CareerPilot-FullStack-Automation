import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

// ✅ Ensure 'export' is here
export interface Job {
  id?: number;
  companyName: string;
  jobRole: string;
  platform: string;
  location: string;
  status: string; 
  notes?: string;
  description?: string;
  createdAt?: any;
  appliedAt?: any;
}

@Injectable({
  providedIn: 'root'
})
// ✅ Ensure 'export' is here
export class JobService {
  private apiUrl = 'http://localhost:8080/api/jobs';

  constructor(private http: HttpClient) { }

  getAllJobs(): Observable<Job[]> {
    return this.http.get<Job[]>(this.apiUrl);
  }
}