import { TestBed } from '@angular/core/testing';
import { AppComponent } from './app'; // ✅ Change this from './app.component' to './app'

describe('AppComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AppComponent],
    }).compileComponents();
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it('should render title', async () => {
    const fixture = TestBed.createComponent(AppComponent);
    await fixture.whenStable();
    const compiled = fixture.nativeElement as HTMLElement;
    // Ensure the text matches what you actually have in your app.html
    expect(compiled.querySelector('h1')?.textContent).toContain('Hello, careerpilot-ui');
  });
});