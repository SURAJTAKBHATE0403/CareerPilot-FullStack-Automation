import { ApplicationConfig } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { routes } from './app.routes';
import { authInterceptor } from './core/interceptors/auth-interceptor'; // Import it!

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),
    // Activate the interceptor here
    provideHttpClient(withInterceptors([authInterceptor])) 
  ]
};