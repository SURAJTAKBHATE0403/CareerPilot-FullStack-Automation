import os
import time
import random
import requests
from dotenv import load_dotenv
from selenium import webdriver

load_dotenv()

class BaseBot:
    def __init__(self, daily_limit=25):
        self.daily_limit = daily_limit
        self.applied_count = 0
        self.telegram_token = os.getenv('TELEGRAM_TOKEN')
        self.telegram_chat_id = os.getenv('TELEGRAM_CHAT_ID')
        self.driver = self.setup_driver()

    def setup_driver(self):
        """Sets up a stealthy Chrome WebDriver using modern Selenium 4+ built-in manager"""
        options = webdriver.ChromeOptions()
        options.add_argument("--start-maximized")
        options.add_experimental_option('excludeSwitches', ['enable-logging', 'enable-automation'])
        options.add_experimental_option('useAutomationExtension', False)
        # Adding a realistic user agent helps avoid bot detection
        options.add_argument("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
        
        # FIX: We removed ChromeDriverManager().install(). Selenium handles this natively now!
        driver = webdriver.Chrome(options=options)
        
        # Stealth execution to hide Selenium
        driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
        return driver

    def human_like_scroll(self, duration_seconds):
        """Simulates human behavior by scrolling randomly during breaks"""
        print(f" Human simulation: Scrolling for {duration_seconds//60} minutes...")
        end_time = time.time() + duration_seconds
        while time.time() < end_time:
            scroll_amount = random.randint(300, 800)
            direction = random.choice([scroll_amount, -scroll_amount])
            try:
                self.driver.execute_script(f"window.scrollBy(0, {direction});")
            except:
                pass
            time.sleep(random.randint(4, 10))

    def send_telegram_msg(self, role, company):
        """Sends a notification to your Telegram bot"""
        if not self.telegram_token or not self.telegram_chat_id:
            return
            
        try:
            msg = f" *Job Applied! ({self.applied_count}/{self.daily_limit})*\n *Company:* {company}\n *Role:* {role}\n CareerPilot AI"
            url = f"https://api.telegram.org/bot{self.telegram_token}/sendMessage"
            payload = {"chat_id": self.telegram_chat_id, "text": msg, "parse_mode": "Markdown"}
            requests.post(url, data=payload)
        except Exception as e:
            print(f" Telegram notification failed: {e}")
            
    def close(self):
        self.driver.quit()