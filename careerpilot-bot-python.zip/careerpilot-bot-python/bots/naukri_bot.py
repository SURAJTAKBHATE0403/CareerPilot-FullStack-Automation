import os
import time
import random
import re
import sys
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Ensure the project root is in the path for internal imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from bots.base_bot import BaseBot
from utils.form_handler import USER_PROFILE, TARGET_ROLES
from utils import api_client

class NaukriBot(BaseBot):
    def __init__(self, daily_limit=50):
        super().__init__(daily_limit)
        self.email = os.getenv('NAUKRI_EMAIL')
        self.password = os.getenv('NAUKRI_PASSWORD')
        self.wait = WebDriverWait(self.driver, 15)

    def find_smart_answer(self, question_text):
        q_text = question_text.lower()
        for key, value in USER_PROFILE.items():
            if key.lower() in q_text:
                return value
        return "Yes" 

    def login(self):
        print(" Logging into Naukri...")
        try:
            self.driver.get("https://www.naukri.com/nlogin/login")
            self.wait.until(EC.presence_of_element_located((By.ID, "usernameField"))).send_keys(self.email)
            time.sleep(random.randint(3, 6))
            self.driver.find_element(By.ID, "passwordField").send_keys(self.password)
            time.sleep(random.randint(3, 6))
            self.driver.find_element(By.XPATH, "//button[@type='submit']").click()
            print(" Login Successful!")
            time.sleep(random.randint(8, 15))
        except Exception as e:
            print(f" Login Error: {e}")
            self.close()
            sys.exit(1)

    def boost_profile_visibility(self):
        """Edits Key Skills briefly to refresh the 'last updated' timestamp on Naukri."""
        try:
            self.driver.get("https://www.naukri.com/mnjuser/profile")
            time.sleep(random.randint(8, 12))
            edit_btn = self.wait.until(EC.element_to_be_clickable(
                (By.XPATH, "//span[text()='Key Skills']/following-sibling::span[contains(@class,'edit')] | //div[@class='keySkills']//span[@class='edit']")
            ))
            edit_btn.click()
            time.sleep(random.randint(4, 6))
            self.wait.until(EC.element_to_be_clickable((By.ID, "submitSkill"))).click()
            print(" Profile visibility boosted!")
            time.sleep(random.randint(6, 10))
        except:
            print(" Profile boost skipped")

    def fill_forms(self):
        """Handles chatbot-style screening questions on Naukri."""
        read_time = random.randint(30, 60)
        print(f" Human-like reading: {read_time}s...")
        time.sleep(read_time)

        for _ in range(12):
            try:
                time.sleep(random.randint(4, 8))
                questions = self.driver.find_elements(By.CSS_SELECTOR, ".msg-text, .chat-message-text, .question-text, .desc")
                if not questions: break

                last_q = questions[-1].text.lower()
                print(f" Question: {last_q}")

                answer = self.find_smart_answer(last_q)
                
                # Filter out roles requiring too much experience
                if any(word in last_q for word in ["3 years", "4 years", "5 years", "6 years"]):
                    print(" Role requires high experience. Skipping...")
                    return "SKIP"

                # Look for radio buttons/chips first
                options = self.driver.find_elements(By.CSS_SELECTOR, ".radio-option, .tap-chip, .suggested-option, li.radio-option")
                clicked = False
                for opt in options:
                    opt_text = opt.text.lower()
                    if str(answer).lower() in opt_text or any(k in opt_text for k in ["yes", "immediate", "0", "bachelor"]):
                        self.driver.execute_script("arguments[0].click();", opt)
                        clicked = True
                        time.sleep(random.randint(3, 5))
                        break

                # If no buttons, look for text inputs
                if not clicked:
                    inputs = self.driver.find_elements(By.CSS_SELECTOR, "input, textarea, div[contenteditable='true']")
                    for inp in inputs:
                        if inp.is_displayed():
                            inp.send_keys(str(answer))
                            inp.send_keys(Keys.ENTER)
                            time.sleep(random.randint(3, 5))
                            break

                # Click 'Save' or 'Next'
                buttons = self.driver.find_elements(By.XPATH, "//button[contains(text(),'Save') or contains(text(),'Submit') or contains(text(),'Next')]")
                for b in buttons:
                    if b.is_displayed():
                        self.driver.execute_script("arguments[0].click();", b)
                        time.sleep(random.randint(5, 8))
                        break

                if "success" in self.driver.page_source.lower() or "applied" in self.driver.page_source.lower():
                    return "SUCCESS"
            except: break
        return "SUCCESS"

    def apply_to_jobs(self):
        for role in TARGET_ROLES:
            if self.applied_count >= self.daily_limit: break
            print(f"\n Searching: {role}")

            # Search Pune/Mumbai area with 0-1 years exp filter
            for page in range(1, 4):
                if self.applied_count >= self.daily_limit: break
                url = f"https://www.naukri.com/{role.replace(' ', '-')}-jobs-in-pune-mumbai?experience=0&k={role.replace(' ', '%20')}&experienceLimit=1&pageNo={page}"
                self.driver.get(url)
                self.human_like_scroll(random.randint(30, 60))

                job_cards = self.driver.find_elements(By.CLASS_NAME, "srp-jobtuple-wrapper")
                for job in job_cards:
                    if self.applied_count >= self.daily_limit: break
                    try:
                        role_name = job.find_element(By.CLASS_NAME, "title").text
                        company = job.find_element(By.CLASS_NAME, "comp-name").text

                        # --- STEP 1: PRE-CLICK COMPETITION FILTER ---
                        try:
                            stats_text = job.find_element(By.CLASS_NAME, "stats").text
                            applicants = int(re.findall(r'\d+', stats_text)[0])
                            if applicants > 150:
                                print(f" Skipping {company} (High Competition: {applicants} applicants)")
                                continue
                        except: pass

                        # --- STEP 2: OPEN JOB & SCRAPE DESCRIPTION ---
                        self.driver.execute_script("arguments[0].click();", job.find_element(By.CLASS_NAME, "title"))
                        self.driver.switch_to.window(self.driver.window_handles[-1])
                        time.sleep(random.randint(6, 10))

                        job_description = "Description not found."
                        try:
                            jd_elem = self.wait.until(EC.presence_of_element_located((By.CLASS_NAME, "job-desc")))
                            job_description = jd_elem.text
                        except:
                            try:
                                jd_elem = self.driver.find_element(By.XPATH, "//section[contains(@class,'job-desc')]")
                                job_description = jd_elem.text
                            except: pass

                        # Log job to database immediately with the full JD
                        db_job_id = api_client.log_new_job(company, role_name, "Naukri", "Pune/Mumbai", job_description)
                        if not db_job_id: 
                            self.driver.close()
                            self.driver.switch_to.window(self.driver.window_handles[0])
                            continue

                        # --- STEP 3: EASY APPLY CHECK ---
                        apply_btn = None
                        selectors = [(By.ID, "apply-button"), (By.XPATH, "//button[contains(text(), 'Apply')]")]
                        
                        for selector in selectors:
                            try:
                                apply_btn = self.wait.until(EC.element_to_be_clickable(selector))
                                if apply_btn: break
                            except: continue

                        if apply_btn:
                            btn_text = apply_btn.text.lower()
                            # If it redirects to an external site, skip it
                            if any(word in btn_text for word in ["company site", "external", "redirect", "official"]):
                                print(f" Skipped {company} (External Site)")
                                api_client.update_job_status(db_job_id, "SKIPPED", "External Redirect")
                            else:
                                print(f" Easy Apply found for {company}. Processing...")
                                self.driver.execute_script("arguments[0].click();", apply_btn)
                                
                                if self.fill_forms() != "SKIP":
                                    self.applied_count += 1
                                    api_client.update_job_status(db_job_id, "APPLIED", "Success")
                                    self.send_telegram_msg(role_name, company)
                                    print(f" Application {self.applied_count} submitted!")
                        else:
                            api_client.update_job_status(db_job_id, "SKIPPED", "No Apply Button")

                        # Return to search results
                        self.driver.close()
                        self.driver.switch_to.window(self.driver.window_handles[0])
                        time.sleep(random.randint(5, 10))

                    except Exception as e:
                        if len(self.driver.window_handles) > 1:
                            self.driver.close()
                            self.driver.switch_to.window(self.driver.window_handles[0])
                        continue
                
                print(" Human break (3-5 mins)...")
                time.sleep(random.randint(180, 300))

if __name__ == "__main__":
    if api_client.login_to_api():
        bot = NaukriBot(daily_limit=50)
        bot.login()
        bot.boost_profile_visibility()
        bot.apply_to_jobs()
        bot.close()