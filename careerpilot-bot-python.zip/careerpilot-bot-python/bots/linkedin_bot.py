import os
import time
import random
import re
import sys
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from bots.base_bot import BaseBot
from utils.form_handler import USER_PROFILE, TARGET_ROLES
from utils import api_client

class LinkedInBot(BaseBot):
    def __init__(self, daily_limit=50):
        super().__init__(daily_limit)
        self.email = os.getenv('LINKEDIN_EMAIL')
        self.password = os.getenv('LINKEDIN_PASSWORD')
        self.wait = WebDriverWait(self.driver, 15)

    def find_smart_answer(self, question_text):
        q_text = question_text.lower()
        for key, value in USER_PROFILE.items():
            if key.lower() in q_text:
                return value
        if any(k in q_text for k in ["salary", "expected", "ctc"]): 
            return USER_PROFILE.get("expected ctc", "3.5")
        return "Yes"

    def login(self):
        print(" Logging into LinkedIn...")
        try:
            self.driver.get("https://www.linkedin.com/login")
            time.sleep(3)
            self.driver.find_element(By.ID, "username").send_keys(self.email)
            self.driver.find_element(By.ID, "password").send_keys(self.password)
            self.driver.find_element(By.ID, "password").submit()
            print(" Login successful! Waiting for security...")
            time.sleep(15) 
        except Exception as e:
            print(f" Login Error: {e}")
            self.close()
            sys.exit(1)

    def _check_applicants_relaxed(self) -> bool:
        try:
            subtitle = self.driver.find_element(By.CLASS_NAME, "tvm__text").text.lower()
            match = re.search(r'(\d+)', subtitle)
            if match:
                return int(match.group(1)) <= 150
            return True
        except: return True

    def fill_form_fields(self):
        try:
            inputs = self.driver.find_elements(By.CSS_SELECTOR, "input[type='text'], input[type='number'], textarea")
            for inp in inputs:
                if inp.is_displayed() and inp.get_attribute("value") == "":
                    label_text = self.driver.execute_script("return arguments[0].labels[0] ? arguments[0].labels[0].innerText : '';", inp)
                    answer = self.find_smart_answer(label_text or inp.get_attribute("name"))
                    inp.send_keys(str(answer))
            
            radios = self.driver.find_elements(By.CSS_SELECTOR, "fieldset")
            for field in radios:
                q_text = field.text.lower()
                answer = str(self.find_smart_answer(q_text)).lower()
                try:
                    option = field.find_element(By.XPATH, f".//label[contains(translate(., 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '{answer}')]")
                    self.driver.execute_script("arguments[0].click();", option)
                except: pass
        except: pass

    def process_application(self, company, role, db_job_id):
        base_delay = random.randint(40, 80)
        print(f"⏳ Filling form for {company} ({base_delay}s)...")
        
        for _ in range(10): 
            try:
                time.sleep(base_delay // 4)
                self.fill_form_fields()
                
                buttons = self.driver.find_elements(By.XPATH, "//button[contains(., 'Next') or contains(., 'Review') or contains(., 'Submit')]")
                if not buttons: break

                for btn in buttons:
                    if btn.is_displayed() and btn.is_enabled():
                        if "Submit" in btn.text:
                            self.driver.execute_script("arguments[0].click();", btn)
                            self.applied_count += 1
                            api_client.update_job_status(db_job_id, "APPLIED", "Success")
                            self.send_telegram_msg(role, company)
                            return True
                        else:
                            self.driver.execute_script("arguments[0].click();", btn)
                            break 
            except: break
        return False

    def apply_to_jobs(self):
        for target_role in TARGET_ROLES:
            if self.applied_count >= self.daily_limit: return
            print(f"\n Searching for: {target_role}")
            
            search_url = f"https://www.linkedin.com/jobs/search/?f_AL=true&keywords={target_role.replace(' ', '%20')}&location=Pune%2C%20Mumbai&geoId=104111361%2C106164952&f_TPR=r86400&f_E=2"
            self.driver.get(search_url)
            time.sleep(10)

            for index in range(25):
                if self.applied_count >= self.daily_limit: return
                
                retry = 0
                job = None
                while retry < 3:
                    try:
                        cards = self.wait.until(EC.presence_of_all_elements_located((By.CLASS_NAME, "job-card-container")))
                        if index >= len(cards): break
                        job = cards[index]
                        self.driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", job)
                        time.sleep(2)
                        self.driver.execute_script("arguments[0].click();", job)
                        time.sleep(random.randint(8, 15))
                        break
                    except:
                        retry += 1
                        print(f" Retry {retry}/3...")
                        self.driver.refresh()
                        time.sleep(5)

                if not job: continue

                try:
                    title = self.wait.until(EC.presence_of_element_located((By.CLASS_NAME, "job-details-jobs-unified-top-card__job-title"))).text
                    company = self.driver.find_element(By.CLASS_NAME, "job-details-jobs-unified-top-card__company-name").text
                    
                    #  SPECIFIC SCRAPING LOGIC: LinkedIn Description
                    job_description = "Description not found."
                    try:
                        # LinkedIn uses #job-details for the main description container
                        jd_container = self.wait.until(EC.presence_of_element_located((By.ID, "job-details")))
                        job_description = jd_container.text
                    except:
                        # Fallback for different UI versions
                        try:
                            jd_container = self.driver.find_element(By.CLASS_NAME, "jobs-description")
                            job_description = jd_container.text
                        except: pass

                    # LOG NEW JOB (Pass the description as the 5th argument)
                    db_job_id = api_client.log_new_job(company, title, "LinkedIn", "India", job_description)
                    if not db_job_id: continue

                    if not self._check_applicants_relaxed():
                        api_client.update_job_status(db_job_id, "SKIPPED", "High Competition")
                        continue

                    # --- UPDATED EASY APPLY CHECK ---
                    apply_btns = self.driver.find_elements(By.CSS_SELECTOR, ".jobs-apply-button")
                    
                    is_easy_apply = False
                    target_btn = None

                    if apply_btns:
                        for btn in apply_btns:
                            if "easy apply" in btn.text.lower():
                                is_easy_apply = True
                                target_btn = btn
                                break

                    if is_easy_apply and target_btn:
                        main_window = self.driver.current_window_handle
                        
                        print(f"⏳ Clicking Easy Apply for {company}...")
                        self.driver.execute_script("arguments[0].click();", target_btn)
                        time.sleep(3)

                        if len(self.driver.window_handles) > 1:
                            print(f">>> Skipped: {company} (Opened external site in new tab)")
                            api_client.update_job_status(db_job_id, "SKIPPED", "External Redirect")
                            for handle in self.driver.window_handles:
                                if handle != main_window:
                                    self.driver.switch_to.window(handle)
                                    self.driver.close()
                            self.driver.switch_to.window(main_window)
                            continue

                        self.process_application(company, title, db_job_id)
                        self.human_like_scroll(random.randint(45, 90))
                    else:
                        print(f">>> Skipped: {company} (Not an Easy Apply job)")
                        api_client.update_job_status(db_job_id, "SKIPPED", "External/Manual")

                except Exception as e:
                    print(f"! Card Error: {e}")
                    continue
            
            print(" Human break (3-6 mins)...")
            time.sleep(random.randint(180, 360))

if __name__ == "__main__":
    if api_client.login_to_api():
        bot = LinkedInBot(daily_limit=50)
        bot.login()
        bot.apply_to_jobs()
        bot.close()