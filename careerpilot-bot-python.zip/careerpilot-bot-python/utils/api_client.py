import os
import requests
import logging
from dotenv import load_dotenv

# Load environment variables
load_dotenv()
API_EMAIL = os.getenv('API_EMAIL')
API_PASSWORD = os.getenv('API_PASSWORD')

BASE_URL = "http://localhost:8080/api"
JWT_TOKEN = None

# Set up logging to look clean in the terminal
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

def login_to_api():
    """Authenticates with the Spring Boot backend and retrieves the JWT token."""
    global JWT_TOKEN
    url = f"{BASE_URL}/auth/login"
    payload = {
        "email": API_EMAIL,
        "password": API_PASSWORD
    }
    
    try:
        response = requests.post(url, json=payload)
        if response.status_code == 200:
            JWT_TOKEN = response.json().get("token")
            logging.info(" Successfully authenticated with Spring Boot API!")
            return True
        else:
            logging.error(f" API Login Failed: {response.text}")
            return False
    except requests.exceptions.ConnectionError:
        logging.error(" Could not connect to API. Is Spring Boot running on port 8080?")
        return False

def get_headers():
    """Helper function to attach the JWT token to requests."""
    if not JWT_TOKEN:
        logging.warning(" No JWT Token found. Did the bot log in?")
        return {"Content-Type": "application/json"}
    return {
        "Authorization": f"Bearer {JWT_TOKEN}",
        "Content-Type": "application/json"
    }

def log_new_job(company_name, job_role, platform, location="Pune, Maharashtra", description=""):
    """Sends a newly scraped job to the database including the full JD."""
    url = f"{BASE_URL}/jobs/log"
    payload = {
        "companyName": company_name,
        "jobRole": job_role,
        "location": location,
        "platform": platform,
        "description": description, #  New JD field
        "status": "PENDING",
        "notes": "Scraped via CareerPilot Bot"
    }
    
    try:
        response = requests.post(url, json=payload, headers=get_headers())
        if response.status_code == 201:
            job_id = response.json().get('id')
            logging.info(f" DB Saved: {job_role} at {company_name}")
            return job_id
        elif response.status_code == 400:
            logging.warning(f" DB Skip: Duplicate job - {job_role} at {company_name}")
            return None
        else:
            logging.error(f" API Error ({response.status_code}): {response.text}")
            return None
    except Exception as e:
        logging.error(f" Request failed: {e}")
        return None

def update_job_status(job_id, new_status, notes=""):
    """Updates the status of an existing job (e.g., APPLIED)."""
    if not job_id:
        return False
        
    url = f"{BASE_URL}/jobs/{job_id}/status"
    params = {"status": new_status, "notes": notes}
    
    try:
        response = requests.patch(url, params=params, headers=get_headers())
        if response.status_code == 200:
            logging.info(f" DB Update: Job ID {job_id} marked as {new_status}")
            return True
        else:
            logging.error(f" API Update Error ({response.status_code}): {response.text}")
            return False
    except Exception as e:
        logging.error(f" Update failed: {e}")
        return False