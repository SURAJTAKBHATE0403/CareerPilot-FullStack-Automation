# 1. PERSONAL & CONTACT DATA
USER_DATA = {
    "full_name": "Suraj Hanumant Takbhate",
    "first_name": "Suraj",
    "last_name": "Takbhate",
    "email": "surajtakbhate01@gmail.com",
    "phone": "9370678243",
    "linkedin": "https://linkedin.com/in/surajtakbhate/",
    "github": "https://github.com/SURAJTAKBHATE0403",
    "city": "Pune",
    "state": "Maharashtra",
    "address": "Pune, Maharashtra",
}

# 2. ACADEMIC DATA (Mapped from your Resume)
ACADEMIC_DATA = {
    "university": "B.P.S.C.C Barshi (Solapur University)",
    "degree": "Bachelor of Computer Applications (BCA)",
    "major": "Computer Applications",
    "graduation_year": "2024",
    "percentage": "70.76",
    "hsc_percentage": "65.17",
    "ssc_percentage": "64.60",
}

# 3. KEYWORD-TO-ANSWER MAPPING (The Bot's Brain)
# The bot looks for these keywords in the question and types the Answer.
USER_PROFILE = {
    # Professional Logic
    "notice": "Immediate",
    "experience": "0",
    "current ctc": "0.00",
    "expected ctc": "2.5", # Standard 3.5 LPA
    "salary": "250000",
    
    # Relocation & Compliance (Always Yes to pass filters)
    "relocate": "Yes",
    "comfortable": "Yes",
    "authorized": "Yes",
    "visa": "No", # "Do you require visa?" -> No
    "on-site": "Yes",
    "shifts": "Yes",
    "night": "Yes",
    "24/7": "Yes",
    
    # Academic Keywords
    "qualification": ACADEMIC_DATA["degree"],
    "college": ACADEMIC_DATA["university"],
    "percentage": ACADEMIC_DATA["percentage"],
    "hsc": ACADEMIC_DATA["hsc_percentage"],
    "ssc": ACADEMIC_DATA["ssc_percentage"],
    "gap": "No",
    
    # Fallbacks
    "pune": "Yes",
    "mumbai": "Yes",
    "location": "Yes",
    "graduate": "Yes",
    "title": "Fresher",
    "headline": "Java Full Stack Developer"
}

# Target roles to search for
TARGET_ROLES = [
    "Java Developer", "Junior Java Developer", "Java Backend Developer", 
    "Full Stack Developer", "Software Engineer", "Backend Developer", 
    "Web Developer", "Java Developer Fresher", "Spring Boot Developer",
    "Java API Developer", "Software Trainee"
]