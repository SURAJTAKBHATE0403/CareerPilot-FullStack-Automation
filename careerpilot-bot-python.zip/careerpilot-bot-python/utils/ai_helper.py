import os
import google.generativeai as genai
from dotenv import load_dotenv
import logging

load_dotenv()

# Configure the Gemini API
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))

# Use the Gemini 1.5 Flash model (it's incredibly fast, perfect for real-time bot interactions)
model = genai.GenerativeModel('gemini-1.5-flash')

# Define your core context (Resume + Preferences)
USER_CONTEXT = """
My name is Suraj Hanumant Takbhate. I am a fresher looking for entry-level Software Engineering, 
Java Full Stack, and Backend Developer roles in Pune and Mumbai. 
I have 0 years of professional experience (I am a fresher). 
My skills include Java, Spring Boot, Hibernate, MySQL, HTML5, CSS3, and JavaScript. 
I am comfortable working from the office, relocating to Pune/Mumbai, and joining immediately. 
My expected CTC is 2.5 LPA. I have a Bachelor's degree.
Projects: CareerPilot Automated Job Acquisition System, TempusMail-Replica.
"""

def answer_screening_question(question: str, options: list = None) -> str:
    """
    Uses Gemini to answer unexpected application questions based on the user's resume.
    If 'options' are provided (like radio buttons), it will pick the best one.
    """
    try:
        prompt = f"""
        You are an AI assistant helping Suraj fill out a job application.
        Based on Suraj's profile below, answer the following application question.
        
        Suraj's Profile:
        {USER_CONTEXT}
        
        Question: "{question}"
        """
        
        if options:
            prompt += f"\nYou MUST choose exactly ONE of the following options, output nothing else: {', '.join(options)}"
        else:
            prompt += "\nProvide a very short, direct answer (1-3 words if possible, no conversational filler)."

        response = model.generate_content(prompt)
        answer = response.text.strip()
        logging.info(f" Gemini Answered: '{question}' -> '{answer}'")
        return answer
        
    except Exception as e:
        logging.error(f" Gemini API Error: {e}")
        return "0" # Safe fallback for numeric questions

def evaluate_job_description(job_title: str, job_description: str) -> bool:
    """
    Uses Gemini to read the actual JD and determine if it's suitable for a fresher.
    """
    try:
        prompt = f"""
        Analyze this job posting. 
        Job Title: {job_title}
        Job Description: {job_description}
        
        Does this job STRICTLY accept freshers (0 years experience)? 
        Answer ONLY 'YES' or 'NO'. If it requires 1 or more years of experience, answer 'NO'.
        """
        response = model.generate_content(prompt)
        decision = response.text.strip().upper()
        
        if "YES" in decision:
            return True
        return False
        
    except Exception as e:
        logging.error(f" Gemini Evaluation Error: {e}")
        return False